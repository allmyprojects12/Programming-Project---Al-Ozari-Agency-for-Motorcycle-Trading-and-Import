﻿namespace DataGridTableStyle.DefaultTableStyle
{
    internal class ForeColor
    {
    }
}