﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Text.RegularExpressions;
using System.Threading.Tasks;
using System.Drawing.Printing;
using System.Windows.Forms;

namespace مشروع_برمجة_1
{
    public partial class Form1 : Form
    {
       
        public Form1()
        {
            InitializeComponent();
            printPreviewDialog1.Document = printDocument1;
        }

        private void Form1_Load(object sender, EventArgs e)
        {
            
            datetext.Text = DateTime.Now.ToString("yyyy/MM/dd");
            Dictionary<int, string> itemdata = new Dictionary<int, string>();
            itemdata.Add(520000, "دراجة:"+" Shineray  XY400  ");
            itemdata.Add(400000, " دراجة: Shineray XY250GY ");// اسم الصنف ,سعر الوحدة
            itemdata.Add(350000, " دراجة: Shineray XY200GY ");
            itemdata.Add(300000, "دراجة: Shineray XY150-11  ");
            itemdata.Add(250000, "دراجة: Shineray  XY125-10 ");
            itemdata.Add(180000, "دراجة: Shineray   XY50Q   ");
            itemdata.Add(100000, " محرك بديل دراجة: Shineray XY400 ");
            itemdata.Add(40000, "محرك بديل دراجة:Shineray XY50Q");
            itemdata.Add(70000, "محرك بديل دراجة: Shineray XY250GY");
            itemdata.Add(30000, "إطار دراجة: Shineray  XY400  ");
            itemdata.Add(200000, "إطار دراجة: Shineray  XY200GY  ");
            itemdata.Add(12000, "إطار دراجة: Shineray  XY150-11 ");
            itemdata.Add(9000, "إطار دراجة: Shineray XY50Q ");
      


            itemcomb.DataSource = new BindingSource(itemdata, null);
            itemcomb.DisplayMember = "value";
            itemcomb.ValueMember = "key";

            pricetext.Text = itemcomb.SelectedValue.ToString();


            
            if (alldata.Columns.Count > 0)
            {

            foreach (DataGridViewColumn col in alldata.Columns)
            {
                  col.DefaultCellStyle.ForeColor = Color.DarkBlue;

             }
                alldata.Columns[0].DefaultCellStyle.ForeColor = Color.Black;

                alldata.Columns[1]. DefaultCellStyle.ForeColor  = Color.Green;
                alldata.Columns[3].DefaultCellStyle.ForeColor = Color.Red;

            }



            nametext.Focus();
            nametext.Select();
            nametext.SelectAll();

           
        }

        private void label2_Click(object sender, EventArgs e)
        {
            System.Diagnostics.Process.Start("https://www.alawzari-company.com/");
        }

        private void textBox1_KeyPress(object sender, KeyPressEventArgs e)
        {
            e.Handled = true;
        }

        private void textBox2_KeyPress(object sender, KeyPressEventArgs e)
        {
            e.Handled = true;
        }

        private void textBox2_MouseDown(object sender, MouseEventArgs e)
        {
            if (e.Button == MouseButtons.Right)
            {
                datetext.ContextMenu = new ContextMenu();
            }
        }

        private void textBox6_KeyPress(object sender, KeyPressEventArgs e)
        {
            e.Handled = true;
        }

        private void label1_Click(object sender, EventArgs e)
        {

        }

        private void textBox2_TextChanged(object sender, EventArgs e)
        {

        }

        private void textBox3_KeyDown(object sender, KeyEventArgs e)
        {
            if(e.KeyData==Keys.Enter)
            {
               itemcomb .Focus();
            }
        }

        private void comboBox1_SelectedIndexChanged(object sender, EventArgs e)
        {
            pricetext.Text = itemcomb.SelectedValue.ToString();
        }

        private void comboBox1_KeyDown(object sender, KeyEventArgs e)
        {
            if (e.KeyData == Keys.Enter)
            {
                pricetext.Focus();
            }

        }

        private void textBox5_KeyDown(object sender, KeyEventArgs e)
        {

        }

        private void textBox4_TextChanged(object sender, EventArgs e)
        {

        }

        private void textBox5_TextChanged(object sender, EventArgs e)
        {

        }

        private void textBox4_TextChanged_1(object sender, EventArgs e)
        {

        }

        private void textBox4_KeyDown(object sender, KeyEventArgs e)
        {
            if (e.KeyData == Keys.Enter)
            {
                qutytext.Focus();
                qutytext.Select();
                qutytext.SelectAll();
            }
        }

        private void button1_KeyDown(object sender, KeyEventArgs e)
        {

        }

        private void button1_Click(object sender, EventArgs e)
        {
            if (itemcomb.SelectedIndex <= -1) return;

            string item = itemcomb.Text;
            int quty=Convert.ToInt32 (qutytext.Text);
            int price= Convert.ToInt32(pricetext.Text);
            int total = quty * price;

            object[] row = { item, quty, price, total };
            alldata.Rows.Add(row);

            totaltext.Text = (Convert.ToInt32(totaltext.Text) + total)+"";


        }

        private void textBox5_KeyDown_1(object sender, KeyEventArgs e)
        {
            if (e.KeyData == Keys.Enter)
            {
                addbut.PerformClick();

                itemcomb.Focus();


            }
        }

        private void dataGridView1_CellContentClick(object sender, DataGridViewCellEventArgs e)
        {

        }

        private void textBox4_TextChanged_2(object sender, EventArgs e)
        {

        }

        private void nametext_TextChanged(object sender, EventArgs e)
        {

        }

        private void qutytext_KeyPress(object sender, KeyPressEventArgs e)
        {
            //كود عدم السماح بحروف في صندوق الكمية
            if(!char.IsDigit(e.KeyChar)&&!char.IsControl(e.KeyChar))
            {
                e.Handled = true;
            }
        }
        string oldquty = "1";

        public object PrintPreviewDialog1 { get; private set; }

        private void alldata_CellBeginEdit(object sender, DataGridViewCellCancelEventArgs e)
        {
            if (alldata.CurrentRow!=null)
            {
                oldquty = alldata.CurrentRow.Cells["qutycol"].Value + "";
            }
        }

        private void alldata_CellEndEdit(object sender, DataGridViewCellEventArgs e)
        {
            if (alldata.CurrentRow != null)
            {
                string newquty = alldata.CurrentRow.Cells["qutycol"].Value + "";

                if(!Regex.IsMatch(newquty,"^\\d+$") )
                {
                    alldata.CurrentRow.Cells["qutycol"].Value  =oldquty;

                }
                else if (oldquty==newquty)
                {

                }
                else
                {
                    int price = (int)alldata.CurrentRow.Cells["pricecol"].Value;
                    int quty = Convert.ToInt32(newquty);
                    alldata.CurrentRow.Cells["totalcol"].Value = (price * quty);

                    int newtotal = 0;
                    foreach(DataGridViewRow r in alldata.Rows)
                    {
                        newtotal += Convert.ToInt32(r.Cells["totalcol"].Value);
                    }
                    totaltext.Text = newtotal + "";

                }
            }
        }

        private void dataGridView1_CellContentClick_1(object sender, DataGridViewCellEventArgs e)
        {

        }

        private void printtext_Click(object sender, EventArgs e)
        {

        }

        private void printPreviewDialog1_Load(object sender, EventArgs e)
        {

        }

        private void printDocument1_PrintPage(object sender, PrintPageEventArgs e)
        {
            float margin=30;
            Font f = new Font("Arial", 18, FontStyle.Bold);

            string strNO = "رقم الفاتورة :"+vatext.Text;
            string strdate = "تاريخ الفاتورة :" + datetext.Text;
            string strname = "اسم الزبون :" + nametext.Text;

            SizeF fontsizeno = e.Graphics.MeasureString(strdate, f);
            SizeF fontsizedate = e.Graphics.MeasureString(strNO, f);
            SizeF fontsizename = e.Graphics.MeasureString(strname, f);

            e.Graphics.DrawImage(Properties.Resources.logo,margin, margin,150, 150);
            e.Graphics.DrawString(strNO,f,Brushes.Red,(e.PageBounds.Width+fontsizeno.Width)/2,margin);

            e.Graphics.DrawString(strdate, f, Brushes.Black, e.PageBounds.Width - fontsizedate.Width - margin, margin + fontsizeno.Height);
            e.Graphics.DrawString(strname, f, Brushes.Black, e.PageBounds.Width - fontsizename.Width - margin, margin + fontsizeno.Height+fontsizedate.Height);

            float preheights =margin + fontsizedate.Height + fontsizename.Height + fontsizeno.Height + 70;

            e.Graphics.DrawRectangle(Pens.Black, margin-20, preheights, e.PageBounds.Width - margin  , e.PageBounds.Height-margin-preheights);

           float colheight = 50;
            float colwidth = 150;
            float col1width = 320;
            float col2width = 110 +  col1width;
            float col3width = 110 +  col2width;
            float col4width = 120 + col3width;

            e.Graphics.DrawLine(Pens.Black, margin-20, preheights + colheight, e.PageBounds.Width - margin+10, preheights + colheight);

            e.Graphics.DrawString("الصنف", f, Brushes.Black, e.PageBounds.Width - margin * 2-colwidth, preheights + 10);
            e.Graphics.DrawLine(Pens.Black, e.PageBounds.Width - margin * 2 - col1width, preheights, e.PageBounds.Width - margin * 2 - col1width, e.PageBounds.Height-margin);

            e.Graphics.DrawString("الكمية", f, Brushes.Black, e.PageBounds.Width - margin * 2 - col2width + 30, preheights + 10);
            e.Graphics.DrawLine(Pens.Black, e.PageBounds.Width - margin * 2 - col2width, preheights, e.PageBounds.Width - margin * 2 - col2width, e.PageBounds.Height - margin);

            e.Graphics.DrawString("السعر", f, Brushes.Black, e.PageBounds.Width - margin * 2 - col3width + 30, preheights + 10);
            e.Graphics.DrawLine(Pens.Black, e.PageBounds.Width - margin * 2 - col3width, preheights, e.PageBounds.Width - margin * 2 - col3width, e.PageBounds.Height - margin);

            e.Graphics.DrawString("الاجمالي", f, Brushes.Black,  e.PageBounds.Width - margin * 2   - col4width, preheights + 10);


            ////////////////////////////////محتوى الفاتورة////////////////////
            Font l = new Font("Arial", 16, FontStyle.Bold);

            float rowsheight = 60;

            for (int x=0;x<alldata.Rows.Count;x+=1)
            {
                e.Graphics.DrawString(alldata.Rows[x].Cells[0].Value.ToString(), l, Brushes.Black, e.PageBounds.Width - margin *7 - colwidth, preheights + rowsheight);
                e.Graphics.DrawString(alldata.Rows[x].Cells[2].Value.ToString(), l, Brushes.Black, e.PageBounds.Width - margin * 5 - col2width, preheights + rowsheight);
                e.Graphics.DrawString(alldata.Rows[x].Cells[1].Value.ToString(), l, Brushes.Black, e.PageBounds.Width - margin * 5 - col1width, preheights + rowsheight);
                e.Graphics.DrawString(alldata.Rows[x].Cells[3].Value.ToString(), l, Brushes.Black, e.PageBounds.Width - margin * 2 - col4width, preheights + rowsheight);

                e.Graphics.DrawLine(Pens.Black, margin - 20, preheights + rowsheight + colheight, e.PageBounds.Width - margin +10, preheights + rowsheight + colheight);


                rowsheight += 60;//عند ازالة هذا يتم طباعة الكل في مكان واحد 
            }


            e.Graphics.DrawString("الاجمالي", f, Brushes.Red, e.PageBounds.Width - margin * 5 - col2width, preheights + rowsheight);
            e.Graphics.DrawString("R.Y  "+totaltext.Text, f, Brushes.DarkBlue, e.PageBounds.Width - margin * 2 - col4width-80, preheights + rowsheight);
            e.Graphics.DrawLine(Pens.Black, margin - 20, preheights + rowsheight + colheight, e.PageBounds.Width - margin + 10, preheights + rowsheight + colheight);

        }

        private void printbut_Click(object sender, EventArgs e)
        {
            ((Form)printPreviewDialog1).WindowState = FormWindowState.Maximized;
            if (printPreviewDialog1.ShowDialog() == DialogResult.OK)
            {
                printDocument1.Print();
            }

        }

        private void pictureBox1_Click(object sender, EventArgs e)
        {

        }

        private void textBox1_TextChanged(object sender, EventArgs e)
        {

        }

        private void label5_Click(object sender, EventArgs e)
        {

        }

        private void datetext_Click(object sender, EventArgs e)
        {

        }
    }
}
