﻿namespace مشروع_برمجة_1
{
    partial class Form1
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(Form1));
            this.printbut = new System.Windows.Forms.Button();
            this.totaltext = new System.Windows.Forms.TextBox();
            this.label10 = new System.Windows.Forms.Label();
            this.addbut = new System.Windows.Forms.Button();
            this.alldata = new System.Windows.Forms.DataGridView();
            this.itemcol = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.qutycol = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.pricecol = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.totalcol = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.qutytext = new System.Windows.Forms.TextBox();
            this.label9 = new System.Windows.Forms.Label();
            this.pricetext = new System.Windows.Forms.TextBox();
            this.label8 = new System.Windows.Forms.Label();
            this.itemcomb = new System.Windows.Forms.ComboBox();
            this.label7 = new System.Windows.Forms.Label();
            this.label6 = new System.Windows.Forms.Label();
            this.nametext = new System.Windows.Forms.TextBox();
            this.label5 = new System.Windows.Forms.Label();
            this.datetext = new System.Windows.Forms.TextBox();
            this.vatext = new System.Windows.Forms.TextBox();
            this.vadatetext = new System.Windows.Forms.Label();
            this.label3 = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.logo = new System.Windows.Forms.PictureBox();
            this.label1 = new System.Windows.Forms.Label();
            this.label11 = new System.Windows.Forms.Label();
            this.printDocument1 = new System.Drawing.Printing.PrintDocument();
            this.printPreviewDialog1 = new System.Windows.Forms.PrintPreviewDialog();
            ((System.ComponentModel.ISupportInitialize)(this.alldata)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.logo)).BeginInit();
            this.SuspendLayout();
            // 
            // printbut
            // 
            this.printbut.BackColor = System.Drawing.Color.Teal;
            this.printbut.Font = new System.Drawing.Font("Verdana", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.printbut.ForeColor = System.Drawing.SystemColors.ButtonHighlight;
            this.printbut.Location = new System.Drawing.Point(20, 186);
            this.printbut.Name = "printbut";
            this.printbut.Size = new System.Drawing.Size(75, 54);
            this.printbut.TabIndex = 41;
            this.printbut.Text = "طباعة";
            this.printbut.UseVisualStyleBackColor = false;
            this.printbut.Click += new System.EventHandler(this.printbut_Click);
            // 
            // totaltext
            // 
            this.totaltext.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(64)))), ((int)(((byte)(0)))), ((int)(((byte)(64)))));
            this.totaltext.Font = new System.Drawing.Font("Arial Rounded MT Bold", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.totaltext.ForeColor = System.Drawing.Color.Yellow;
            this.totaltext.Location = new System.Drawing.Point(205, 211);
            this.totaltext.Name = "totaltext";
            this.totaltext.Size = new System.Drawing.Size(154, 29);
            this.totaltext.TabIndex = 39;
            this.totaltext.Text = "0";
            this.totaltext.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            this.totaltext.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.textBox6_KeyPress);
            // 
            // label10
            // 
            this.label10.AutoSize = true;
            this.label10.BackColor = System.Drawing.SystemColors.ButtonHighlight;
            this.label10.Font = new System.Drawing.Font("Bauhaus 93", 18F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label10.ForeColor = System.Drawing.Color.Red;
            this.label10.Location = new System.Drawing.Point(247, 178);
            this.label10.Name = "label10";
            this.label10.Size = new System.Drawing.Size(62, 28);
            this.label10.TabIndex = 38;
            this.label10.Text = "الاجمالي";
            // 
            // addbut
            // 
            this.addbut.BackColor = System.Drawing.Color.Teal;
            this.addbut.Font = new System.Drawing.Font("Verdana", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.addbut.ForeColor = System.Drawing.SystemColors.ButtonHighlight;
            this.addbut.Location = new System.Drawing.Point(116, 186);
            this.addbut.Name = "addbut";
            this.addbut.Size = new System.Drawing.Size(75, 54);
            this.addbut.TabIndex = 40;
            this.addbut.Text = "اضافة";
            this.addbut.UseVisualStyleBackColor = false;
            this.addbut.Click += new System.EventHandler(this.button1_Click);
            // 
            // alldata
            // 
            this.alldata.AccessibleName = "";
            this.alldata.AllowUserToAddRows = false;
            this.alldata.AutoSizeColumnsMode = System.Windows.Forms.DataGridViewAutoSizeColumnsMode.Fill;
            this.alldata.AutoSizeRowsMode = System.Windows.Forms.DataGridViewAutoSizeRowsMode.AllCells;
            this.alldata.BackgroundColor = System.Drawing.SystemColors.ButtonHighlight;
            this.alldata.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.alldata.Columns.AddRange(new System.Windows.Forms.DataGridViewColumn[] {
            this.itemcol,
            this.qutycol,
            this.pricecol,
            this.totalcol});
            this.alldata.Location = new System.Drawing.Point(14, 250);
            this.alldata.Name = "alldata";
            this.alldata.RightToLeft = System.Windows.Forms.RightToLeft.Yes;
            this.alldata.Size = new System.Drawing.Size(793, 206);
            this.alldata.TabIndex = 37;
            this.alldata.CellBeginEdit += new System.Windows.Forms.DataGridViewCellCancelEventHandler(this.alldata_CellBeginEdit);
            this.alldata.CellContentClick += new System.Windows.Forms.DataGridViewCellEventHandler(this.dataGridView1_CellContentClick);
            this.alldata.CellEndEdit += new System.Windows.Forms.DataGridViewCellEventHandler(this.alldata_CellEndEdit);
            // 
            // itemcol
            // 
            this.itemcol.HeaderText = "الصنف";
            this.itemcol.Name = "itemcol";
            this.itemcol.ReadOnly = true;
            // 
            // qutycol
            // 
            this.qutycol.HeaderText = "الكمية";
            this.qutycol.Name = "qutycol";
            // 
            // pricecol
            // 
            this.pricecol.HeaderText = "سعر الوحدة";
            this.pricecol.Name = "pricecol";
            this.pricecol.ReadOnly = true;
            // 
            // totalcol
            // 
            this.totalcol.HeaderText = "الاجمالي";
            this.totalcol.Name = "totalcol";
            this.totalcol.ReadOnly = true;
            // 
            // qutytext
            // 
            this.qutytext.Font = new System.Drawing.Font("Arial Rounded MT Bold", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.qutytext.ForeColor = System.Drawing.Color.Green;
            this.qutytext.Location = new System.Drawing.Point(365, 215);
            this.qutytext.Name = "qutytext";
            this.qutytext.Size = new System.Drawing.Size(175, 29);
            this.qutytext.TabIndex = 36;
            this.qutytext.Text = "1";
            this.qutytext.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            this.qutytext.TextChanged += new System.EventHandler(this.textBox5_TextChanged);
            this.qutytext.KeyDown += new System.Windows.Forms.KeyEventHandler(this.textBox5_KeyDown_1);
            this.qutytext.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.qutytext_KeyPress);
            // 
            // label9
            // 
            this.label9.AutoSize = true;
            this.label9.BackColor = System.Drawing.SystemColors.ButtonHighlight;
            this.label9.Font = new System.Drawing.Font("Arial Rounded MT Bold", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label9.Location = new System.Drawing.Point(542, 218);
            this.label9.Name = "label9";
            this.label9.Size = new System.Drawing.Size(39, 22);
            this.label9.TabIndex = 35;
            this.label9.Text = "الكمية";
            // 
            // pricetext
            // 
            this.pricetext.AutoCompleteMode = System.Windows.Forms.AutoCompleteMode.SuggestAppend;
            this.pricetext.AutoCompleteSource = System.Windows.Forms.AutoCompleteSource.AllUrl;
            this.pricetext.BackColor = System.Drawing.SystemColors.ButtonHighlight;
            this.pricetext.Font = new System.Drawing.Font("Arial Rounded MT Bold", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.pricetext.ForeColor = System.Drawing.Color.Black;
            this.pricetext.Location = new System.Drawing.Point(587, 215);
            this.pricetext.Name = "pricetext";
            this.pricetext.ReadOnly = true;
            this.pricetext.Size = new System.Drawing.Size(163, 29);
            this.pricetext.TabIndex = 34;
            this.pricetext.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            this.pricetext.TextChanged += new System.EventHandler(this.textBox4_TextChanged_1);
            this.pricetext.KeyDown += new System.Windows.Forms.KeyEventHandler(this.textBox4_KeyDown);
            // 
            // label8
            // 
            this.label8.AutoSize = true;
            this.label8.BackColor = System.Drawing.SystemColors.ButtonHighlight;
            this.label8.Font = new System.Drawing.Font("Arial Rounded MT Bold", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label8.Location = new System.Drawing.Point(749, 218);
            this.label8.Name = "label8";
            this.label8.Size = new System.Drawing.Size(69, 22);
            this.label8.TabIndex = 33;
            this.label8.Text = "سعر الوحدة";
            // 
            // itemcomb
            // 
            this.itemcomb.AutoCompleteMode = System.Windows.Forms.AutoCompleteMode.SuggestAppend;
            this.itemcomb.AutoCompleteSource = System.Windows.Forms.AutoCompleteSource.ListItems;
            this.itemcomb.Font = new System.Drawing.Font("Arial Rounded MT Bold", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.itemcomb.FormattingEnabled = true;
            this.itemcomb.Location = new System.Drawing.Point(365, 180);
            this.itemcomb.Name = "itemcomb";
            this.itemcomb.RightToLeft = System.Windows.Forms.RightToLeft.Yes;
            this.itemcomb.Size = new System.Drawing.Size(385, 30);
            this.itemcomb.TabIndex = 32;
            this.itemcomb.SelectedIndexChanged += new System.EventHandler(this.comboBox1_SelectedIndexChanged);
            this.itemcomb.KeyDown += new System.Windows.Forms.KeyEventHandler(this.comboBox1_KeyDown);
            // 
            // label7
            // 
            this.label7.AutoSize = true;
            this.label7.BackColor = System.Drawing.SystemColors.ButtonHighlight;
            this.label7.Font = new System.Drawing.Font("Arial Rounded MT Bold", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label7.Location = new System.Drawing.Point(757, 183);
            this.label7.Name = "label7";
            this.label7.Size = new System.Drawing.Size(48, 22);
            this.label7.TabIndex = 31;
            this.label7.Text = "الصنف";
            // 
            // label6
            // 
            this.label6.BackColor = System.Drawing.Color.White;
            this.label6.Font = new System.Drawing.Font("Arial Rounded MT Bold", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label6.ForeColor = System.Drawing.Color.Gray;
            this.label6.Location = new System.Drawing.Point(16, 160);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(803, 23);
            this.label6.TabIndex = 30;
            this.label6.Text = "---------------------------------------------------------------------------------" +
    "--------------------------------------------------------------------------------" +
    "--";
            // 
            // nametext
            // 
            this.nametext.Font = new System.Drawing.Font("Arial Rounded MT Bold", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.nametext.ForeColor = System.Drawing.Color.Green;
            this.nametext.Location = new System.Drawing.Point(298, 131);
            this.nametext.Name = "nametext";
            this.nametext.RightToLeft = System.Windows.Forms.RightToLeft.Yes;
            this.nametext.Size = new System.Drawing.Size(429, 29);
            this.nametext.TabIndex = 29;
            this.nametext.Text = " \"الاسم\"";
            this.nametext.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            this.nametext.TextChanged += new System.EventHandler(this.nametext_TextChanged);
            this.nametext.KeyDown += new System.Windows.Forms.KeyEventHandler(this.textBox3_KeyDown);
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.BackColor = System.Drawing.SystemColors.ButtonHighlight;
            this.label5.Font = new System.Drawing.Font("Arial Rounded MT Bold", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label5.Location = new System.Drawing.Point(733, 134);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(66, 22);
            this.label5.TabIndex = 28;
            this.label5.Text = "اسم الزبون";
            this.label5.Click += new System.EventHandler(this.label5_Click);
            // 
            // datetext
            // 
            this.datetext.Font = new System.Drawing.Font("Arial Rounded MT Bold", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.datetext.ForeColor = System.Drawing.Color.Purple;
            this.datetext.Location = new System.Drawing.Point(299, 100);
            this.datetext.Name = "datetext";
            this.datetext.Size = new System.Drawing.Size(169, 26);
            this.datetext.TabIndex = 27;
            this.datetext.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            this.datetext.Click += new System.EventHandler(this.datetext_Click);
            this.datetext.TextChanged += new System.EventHandler(this.textBox2_TextChanged);
            this.datetext.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.textBox2_KeyPress);
            this.datetext.MouseDown += new System.Windows.Forms.MouseEventHandler(this.textBox2_MouseDown);
            // 
            // vatext
            // 
            this.vatext.Font = new System.Drawing.Font("Arial Rounded MT Bold", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.vatext.ForeColor = System.Drawing.Color.Red;
            this.vatext.Location = new System.Drawing.Point(559, 100);
            this.vatext.Name = "vatext";
            this.vatext.Size = new System.Drawing.Size(169, 26);
            this.vatext.TabIndex = 26;
            this.vatext.Text = "000000123";
            this.vatext.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            this.vatext.TextChanged += new System.EventHandler(this.textBox1_TextChanged);
            this.vatext.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.textBox1_KeyPress);
            // 
            // vadatetext
            // 
            this.vadatetext.AutoSize = true;
            this.vadatetext.BackColor = System.Drawing.SystemColors.ButtonHighlight;
            this.vadatetext.Font = new System.Drawing.Font("Arial Rounded MT Bold", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.vadatetext.Location = new System.Drawing.Point(474, 103);
            this.vadatetext.Name = "vadatetext";
            this.vadatetext.Size = new System.Drawing.Size(83, 22);
            this.vadatetext.TabIndex = 25;
            this.vadatetext.Text = "تاريخ الفاتورة";
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.BackColor = System.Drawing.SystemColors.ButtonHighlight;
            this.label3.Font = new System.Drawing.Font("Arial Rounded MT Bold", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label3.Location = new System.Drawing.Point(734, 103);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(71, 22);
            this.label3.TabIndex = 24;
            this.label3.Text = "رقم الفاتورة";
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.BackColor = System.Drawing.SystemColors.ButtonHighlight;
            this.label2.Cursor = System.Windows.Forms.Cursors.Hand;
            this.label2.Font = new System.Drawing.Font("Times New Roman", 9.75F, ((System.Drawing.FontStyle)((System.Drawing.FontStyle.Bold | System.Drawing.FontStyle.Underline))), System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label2.ForeColor = System.Drawing.Color.Blue;
            this.label2.Location = new System.Drawing.Point(5, 122);
            this.label2.Name = "label2";
            this.label2.RightToLeft = System.Windows.Forms.RightToLeft.Yes;
            this.label2.Size = new System.Drawing.Size(191, 15);
            this.label2.TabIndex = 23;
            this.label2.Text = "/https://www.alawzar.company.com";
            this.label2.Click += new System.EventHandler(this.label2_Click);
            // 
            // logo
            // 
            this.logo.BackColor = System.Drawing.SystemColors.ControlDark;
            this.logo.Image = global::مشروع_برمجة_1.Properties.Resources.logo;
            this.logo.Location = new System.Drawing.Point(31, 9);
            this.logo.Name = "logo";
            this.logo.Size = new System.Drawing.Size(124, 110);
            this.logo.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.logo.TabIndex = 22;
            this.logo.TabStop = false;
            this.logo.Click += new System.EventHandler(this.pictureBox1_Click);
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.BackColor = System.Drawing.SystemColors.ButtonHighlight;
            this.label1.Font = new System.Drawing.Font("Times New Roman", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label1.ForeColor = System.Drawing.Color.Navy;
            this.label1.Location = new System.Drawing.Point(623, 9);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(182, 38);
            this.label1.TabIndex = 21;
            this.label1.Text = "محلات الاوزري\r\n لتجارة وإستيراد الدراجات النارية";
            this.label1.TextAlign = System.Drawing.ContentAlignment.TopCenter;
            this.label1.Click += new System.EventHandler(this.label1_Click);
            // 
            // label11
            // 
            this.label11.AutoSize = true;
            this.label11.BackColor = System.Drawing.SystemColors.ButtonHighlight;
            this.label11.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
            this.label11.Font = new System.Drawing.Font("Times New Roman", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label11.ForeColor = System.Drawing.Color.Red;
            this.label11.Location = new System.Drawing.Point(348, 9);
            this.label11.Name = "label11";
            this.label11.Size = new System.Drawing.Size(122, 24);
            this.label11.TabIndex = 42;
            this.label11.Text = "فاتورة بيع وشراء";
            this.label11.TextAlign = System.Drawing.ContentAlignment.TopCenter;
            // 
            // printDocument1
            // 
            this.printDocument1.PrintPage += new System.Drawing.Printing.PrintPageEventHandler(this.printDocument1_PrintPage);
            // 
            // printPreviewDialog1
            // 
            this.printPreviewDialog1.AutoScrollMargin = new System.Drawing.Size(0, 0);
            this.printPreviewDialog1.AutoScrollMinSize = new System.Drawing.Size(0, 0);
            this.printPreviewDialog1.ClientSize = new System.Drawing.Size(400, 300);
            this.printPreviewDialog1.Document = this.printDocument1;
            this.printPreviewDialog1.Enabled = true;
            this.printPreviewDialog1.Icon = ((System.Drawing.Icon)(resources.GetObject("printPreviewDialog1.Icon")));
            this.printPreviewDialog1.Name = "printPreviewDialog1";
            this.printPreviewDialog1.Visible = false;
            this.printPreviewDialog1.Load += new System.EventHandler(this.printPreviewDialog1_Load);
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackgroundImage = global::مشروع_برمجة_1.Properties.Resources.Screenshot_20250304_221017_Facebook;
            this.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.CausesValidation = false;
            this.ClientSize = new System.Drawing.Size(821, 459);
            this.Controls.Add(this.label11);
            this.Controls.Add(this.printbut);
            this.Controls.Add(this.totaltext);
            this.Controls.Add(this.label10);
            this.Controls.Add(this.addbut);
            this.Controls.Add(this.alldata);
            this.Controls.Add(this.qutytext);
            this.Controls.Add(this.label9);
            this.Controls.Add(this.pricetext);
            this.Controls.Add(this.label8);
            this.Controls.Add(this.itemcomb);
            this.Controls.Add(this.label7);
            this.Controls.Add(this.label6);
            this.Controls.Add(this.nametext);
            this.Controls.Add(this.label5);
            this.Controls.Add(this.datetext);
            this.Controls.Add(this.vatext);
            this.Controls.Add(this.vadatetext);
            this.Controls.Add(this.label3);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.logo);
            this.Controls.Add(this.label1);
            this.Name = "Form1";
            this.Text = "الاوزري للتجارة والاستيراد";
            this.Load += new System.EventHandler(this.Form1_Load);
            ((System.ComponentModel.ISupportInitialize)(this.alldata)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.logo)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Button printbut;
        private System.Windows.Forms.TextBox totaltext;
        private System.Windows.Forms.Label label10;
        private System.Windows.Forms.Button addbut;
        private System.Windows.Forms.DataGridView alldata;
        private System.Windows.Forms.TextBox qutytext;
        private System.Windows.Forms.Label label9;
        private System.Windows.Forms.TextBox pricetext;
        private System.Windows.Forms.Label label8;
        private System.Windows.Forms.ComboBox itemcomb;
        private System.Windows.Forms.Label label7;
        private System.Windows.Forms.Label label6;
        private System.Windows.Forms.TextBox nametext;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.TextBox datetext;
        private System.Windows.Forms.TextBox vatext;
        private System.Windows.Forms.Label vadatetext;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.PictureBox logo;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Label label11;
        private System.Windows.Forms.DataGridViewTextBoxColumn itemcol;
        private System.Windows.Forms.DataGridViewTextBoxColumn qutycol;
        private System.Windows.Forms.DataGridViewTextBoxColumn pricecol;
        private System.Windows.Forms.DataGridViewTextBoxColumn totalcol;
        private System.Drawing.Printing.PrintDocument printDocument1;
        private System.Windows.Forms.PrintPreviewDialog printPreviewDialog1;
    }
}

